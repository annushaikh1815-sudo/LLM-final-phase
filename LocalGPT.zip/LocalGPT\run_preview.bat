@echo off
title LocalGPT: Browser Preview Launcher
echo ========================================================
echo        LocalGPT: ChatGPT-Style Local AI with RAG & X-Ray
echo ========================================================
echo.
echo Launching LocalGPT interactive interface in your browser...
echo.
start "" "%~dp0index.html"
echo [SUCCESS] LocalGPT launched in your default browser!
timeout /t 3 >nul
exit /b
