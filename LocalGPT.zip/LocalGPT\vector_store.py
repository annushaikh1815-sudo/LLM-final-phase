"""
LocalGPT: Vector Store Module
Manages FAISS vector indexing and similarity search for document chunks.
Includes native high-speed matrix cosine search fallback.
"""

from typing import List, Dict, Any, Tuple
import numpy as np

try:
    import faiss
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False


class VectorStore:
    """
    Manages vector representations and metadata for RAG document chunks.
    Supports FAISS IndexFlatIP (Inner Product) and native NumPy cosine search.
    """

    def __init__(self, dimension: int = 384):
        self.dimension = dimension
        self.chunks: List[Dict[str, Any]] = []
        self.embeddings: Optional[np.ndarray] = None
        self.faiss_index = None
        self._init_faiss()

    def _init_faiss(self):
        if FAISS_AVAILABLE:
            try:
                self.faiss_index = faiss.IndexFlatIP(self.dimension)
                print("[VectorStore] FAISS IndexFlatIP initialized.")
            except Exception as e:
                print(f"[VectorStore] FAISS init failed: {e}. Using native similarity search.")
                self.faiss_index = None
        else:
            self.faiss_index = None

    def add_chunks(self, chunks: List[Dict[str, Any]], embeddings: np.ndarray):
        """Adds text chunks and their normalized embedding vectors into the index."""
        if len(chunks) == 0 or embeddings.shape[0] == 0:
            return

        self.chunks.extend(chunks)

        if self.embeddings is None or self.embeddings.shape[0] == 0:
            self.embeddings = embeddings.astype(np.float32)
        else:
            self.embeddings = np.vstack([self.embeddings, embeddings.astype(np.float32)])

        if self.faiss_index is not None:
            try:
                self.faiss_index.add(embeddings.astype(np.float32))
            except Exception as e:
                print(f"[VectorStore] FAISS add error: {e}")

    def search(self, query_vector: np.ndarray, top_k: int = 5) -> List[Tuple[Dict[str, Any], float]]:
        """
        Executes similarity search, returning top-k matching chunks and similarity scores.
        """
        if not self.chunks or self.embeddings is None or len(self.chunks) == 0:
            return []

        actual_k = min(top_k, len(self.chunks))

        # FAISS search
        if self.faiss_index is not None and self.faiss_index.ntotal > 0:
            try:
                q_vec = query_vector.reshape(1, -1).astype(np.float32)
                scores, indices = self.faiss_index.search(q_vec, actual_k)
                results = []
                for score, idx in zip(scores[0], indices[0]):
                    if 0 <= idx < len(self.chunks):
                        results.append((self.chunks[idx], float(score)))
                return results
            except Exception as e:
                print(f"[VectorStore] FAISS search error: {e}. Falling back to NumPy search.")

        # Native NumPy cosine similarity search
        dot_products = np.dot(self.embeddings, query_vector)
        top_indices = np.argsort(dot_products)[::-1][:actual_k]

        results = []
        for idx in top_indices:
            results.append((self.chunks[idx], float(dot_products[idx])))
        return results

    def clear(self):
        """Resets the vector index and chunks store."""
        self.chunks = []
        self.embeddings = None
        self._init_faiss()

    @property
    def total_chunks(self) -> int:
        return len(self.chunks)

    @property
    def total_documents(self) -> int:
        unique_sources = set(c.get("source", "") for c in self.chunks)
        return len(unique_sources)
