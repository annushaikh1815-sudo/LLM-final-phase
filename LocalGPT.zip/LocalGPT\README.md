# 🤖 LocalGPT : ChatGPT-Style Local AI Assistant with RAG & LLM X-Ray

[![GitHub license](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS-emerald.svg)](#)
[![Interface](https://img.shields.io/badge/UI-Cyber%20Dark%20%26%20Aurora%20Light-indigo.svg)](#)
[![Models](https://img.shields.io/badge/Models-Qwen%202.5%207B%20%7C%20OpenAI%20GPT--4o-rose.svg)](#)

An advanced, production-grade implementation of **LocalGPT** (Project Phase 2), combining **Qwen 2.5 (7B Parameter)** & **OpenAI GPT-4o / o1 / o3** models, **Agentic Voice Assistant (Speech-to-Text & Tool Control)**, **Cross-Chat Persistent Memory**, **Full-Document Deep Analysis (RAG)**, **In-Chat AI Image Generation**, **Multi-Language Code Synthesis**, **1-Click Solution PDF Export**, and **Scientific LLM X-Ray Diagnostics**.

---

## 🌟 Key Features

| No. | Feature Requirement | Implementation in LocalGPT |
|:---:|:---|:---|
| **1** | **Google Sign-In [Firebase]** | Integrated Firebase Auth (`firebase/auth`) with Google Sign-In popup, profile card (avatar, email, role), plus 1-click verified Demo Account fallback. |
| **2** | **Memory (Retain Info From Previous Chats)** | **Cross-Chat Persistent User Memory**: automatically extracts user facts & preferences across sessions and stores them in `localStorage` & JSON state. |
| **3** | **Chat Name (Summarize 1st Prompt Like ChatGPT)** | **Dynamic Title Summarizer**: analyzes the 1st prompt in each session and distills it into an intelligent 3–5 word title in the sidebar with live pulse glow. |
| **4** | **Voice Assistant to Open Tools & Operate** | **Agentic Voice Controller**: Real-time microphone speech-to-text (`webkitSpeechRecognition`) + vocal tool control (*"Open settings"*, *"Switch to dark mode"*, *"Generate image of..."*, *"Analyze document"*, *"Inspect X-Ray"*). |
| **5** | **Document Analyze (Analyze Full Document Based on Prompt)** | **Full Document Deep Analyzer (RAG)**: Ingests PDF/DOCX/TXT files, computes relevant chunk snippets, relevance scores, and displays citation cards with page numbers. |
| **6** | **In-Chat AI Image Generation & Image Studio** | **Neural Diffusion Synthesis**: Type *"generate image of..."* or *"draw..."* to generate 1024×1024 HD artwork directly in chat with a 1-click `💾 Download` button, plus a dedicated **AI Image Studio** modal. |
| **7** | **Multi-Language Code Generation** | **Intelligent Code Synthesizer**: Generates algorithms (Quicksort, Mergesort, Dijkstra, BST), Python scripts, APIs (FastAPI), machine learning models, and web widgets with uppercase language tags and **`📋 Copy Code`** buttons. |
| **8** | **1-Click Solution PDF Export** | **`📥 PDF` Action Chip**: Sits beside `📋 Copy` and `🔗 Share` on every AI message; exports the formatted answer, formulas, code, and citations into a clean PDF. |
| **9** | **Model Selection: Qwen 2.5 (7B) & OpenAI** | Switch dynamically between **Qwen 2.5 (7B Parameter)**, `gpt-4o`, `gpt-4o-mini`, `o1-mini`, and `o3-mini`. |
| **10** | **LLM X-Ray Diagnostic Suite** | Interactive drawer featuring **Tokens (BPE)**, **Logprobs & Top-5 Alternatives**, **2D Embedding PCA Projections**, **Multi-Head Self-Attention Heatmaps**, **Layer Norm Velocities**, and **Cost & Latency Profiler**. |

---

## 📁 Repository Structure

```text
LocalGPT/
├── index.html                 # Standard web app entry point (ready for GitHub Pages / browser)
├── LocalGPT.html              # Primary application interface
├── app.js                     # Complete core logic (Voice, PDF export, RAG, Image Gen, X-Ray)
├── styles.css                 # Cyber Dark & Aurora Light theme stylesheets
├── README.md                  # Comprehensive documentation
├── .gitignore                 # Standard repository ignores
├── requirements.txt           # Python dependencies (for optional backend server)
├── Launch_LocalGPT.bat        # 1-click Windows launcher
├── Open_In_Chrome.bat         # 1-click Chrome launcher
├── push_to_github.bat         # 1-click GitHub commit and push assistant
├── server.py                  # Optional FastAPI / Uvicorn backend server
├── app.py                     # Optional Streamlit interface
├── rag_engine.py              # Python RAG retrieval engine
├── openai_engine.py           # Python LLM engine
├── memory_manager.py          # Python persistent memory manager
├── tokenizer_manager.py       # Python BPE tokenizer
├── xray_engine.py             # Python LLM X-Ray inspector
└── data/                      # Local datasets and document samples
    ├── documents/             # Sample documents for RAG analysis
    └── knowledge/             # Local offline knowledge base (encyclopedia.json)
```

---

## 🚀 Quickstart & How to Run

### Method 1: Instant Browser Launch (Zero Installation)
Simply double-click **`Open_In_Chrome.bat`** or **`Launch_LocalGPT.bat`**, or open **`index.html`** / **`LocalGPT.html`** directly in Google Chrome.
- **Zero dependencies required.**
- Live Voice-to-Text, Solution PDF export, Image generation, Code generation, and LLM X-Ray work immediately out of the box!

### Method 2: Python Backend (Optional)
```bash
pip install -r requirements.txt
python server.py
```

---

## 📤 How to Push This Folder to GitHub

You can push this project to your GitHub account using either option below:

### Option A: Using the Automated Script
Double-click **`push_to_github.bat`** inside this folder. It will initialize Git, commit all files, and prompt you for your GitHub repository URL.

### Option B: Using Git Commands in Terminal
Open **Command Prompt**, **PowerShell**, or **Git Bash** in this folder:

```bash
cd C:\Users\sanab\.gemini\antigravity\scratch\LocalGPT

# 1. Initialize Git repository
git init

# 2. Stage all project files
git add .

# 3. Create initial commit
git commit -m "feat: complete LocalGPT AI assistant with RAG, LLM X-Ray, voice, PDF export, and code/image generation"

# 4. Set main branch
git branch -M main

# 5. Link to your GitHub repository (replace with your repo URL)
git remote add origin https://github.com/<your-username>/<your-repo-name>.git

# 6. Push to GitHub
git push -u origin main
```

---

## 📜 License
This project is licensed under the MIT License.
