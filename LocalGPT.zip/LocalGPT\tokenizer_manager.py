"""
OpenGPT-XRay: Tokenizer Manager Module
Provides subword BPE tokenization, token ID inspection,
and context budgeting using Tiktoken (o200k_base / cl100k_base).
"""

from typing import List, Dict, Any, Tuple
import re

try:
    import tiktoken
    TIKTOKEN_AVAILABLE = True
except ImportError:
    TIKTOKEN_AVAILABLE = False


class TokenizerManager:
    """
    Handles tokenization and vocabulary inspection for OpenAI models.
    """

    def __init__(self, model_name: str = "gpt-4o-mini"):
        self.model_name = model_name
        self.encoding = None
        self._init_encoding()

    def _init_encoding(self):
        if TIKTOKEN_AVAILABLE:
            try:
                # GPT-4o / GPT-4o-mini use o200k_base
                if "4o" in self.model_name or "o1" in self.model_name or "o3" in self.model_name:
                    self.encoding = tiktoken.get_encoding("o200k_base")
                else:
                    self.encoding = tiktoken.get_encoding("cl100k_base")
            except Exception:
                try:
                    self.encoding = tiktoken.encoding_for_model(self.model_name)
                except Exception:
                    self.encoding = tiktoken.get_encoding("cl100k_base")

    def count_tokens(self, text: str) -> int:
        """
        Returns exact token count for the given text.
        """
        if self.encoding:
            return len(self.encoding.encode(text))
        # Fallback estimation (~4 chars per token)
        return max(1, len(text) // 4)

    def count_messages_tokens(self, messages: List[Dict[str, str]]) -> int:
        """
        Calculates token overhead for OpenAI ChatML format.
        Every message takes ~3-4 tokens for role and formatting delimiters.
        """
        num_tokens = 0
        for message in messages:
            num_tokens += 4  # ChatML wrapper tokens: <|im_start|>{role}\n{content}<|im_end|>\n
            for key, value in message.items():
                num_tokens += self.count_tokens(str(value))
        num_tokens += 3  # Assistant reply priming: <|im_start|>assistant\n
        return num_tokens

    def deconstruct_tokens(self, text: str) -> List[Dict[str, Any]]:
        """
        Deconstructs text into individual subword tokens, token IDs, and character spans.
        Used for the '🔤 Tokens' tab in the LLM X-Ray panel.
        """
        if self.encoding:
            token_ids = self.encoding.encode(text)
            tokens_info = []
            char_cursor = 0

            for tid in token_ids:
                try:
                    token_bytes = self.encoding.decode_single_token_bytes(tid)
                    token_str = token_bytes.decode("utf-8", errors="replace")
                except Exception:
                    token_str = f"[{tid}]"

                length = len(token_str)
                tokens_info.append({
                    "id": tid,
                    "token": token_str,
                    "byte_length": len(token_str.encode("utf-8")),
                    "start": char_cursor,
                    "end": char_cursor + length,
                    "is_whitespace": token_str.startswith(" ") or token_str == " "
                })
                char_cursor += length

            return tokens_info

        # Fallback pseudo-tokenizer when tiktoken is unavailable
        words = re.findall(r"\w+|[^\w\s]|\s+", text)
        tokens_info = []
        char_cursor = 0
        base_id = 1000

        for idx, token_str in enumerate(words):
            tokens_info.append({
                "id": base_id + (hash(token_str) % 50000),
                "token": token_str,
                "byte_length": len(token_str.encode("utf-8")),
                "start": char_cursor,
                "end": char_cursor + len(token_str),
                "is_whitespace": token_str.isspace()
            })
            char_cursor += len(token_str)

        return tokens_info
