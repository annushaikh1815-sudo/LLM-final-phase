"""
LocalGPT: Tokenizer Module
Handles prompt tokenization, subword BPE extraction, and token ID mapping
for Qwen/Qwen2.5-1.5B-Instruct.
"""

from typing import List, Dict, Any, Optional
import re

try:
    from transformers import AutoTokenizer
    HF_TOKENIZER_AVAILABLE = True
except ImportError:
    HF_TOKENIZER_AVAILABLE = False


SOFT_CHIP_COLORS = [
  {"bg": "rgba(99, 102, 241, 0.12)", "border": "rgba(99, 102, 241, 0.3)", "text": "#4F46E5"},
  {"bg": "rgba(16, 185, 129, 0.12)", "border": "rgba(16, 185, 129, 0.3)", "text": "#059669"},
  {"bg": "rgba(245, 158, 11, 0.12)", "border": "rgba(245, 158, 11, 0.3)", "text": "#D97706"},
  {"bg": "rgba(244, 63, 94, 0.12)", "border": "rgba(244, 63, 94, 0.3)", "text": "#E11D48"},
  {"bg": "rgba(6, 182, 212, 0.12)", "border": "rgba(6, 182, 212, 0.3)", "text": "#0891B2"},
  {"bg": "rgba(139, 92, 246, 0.12)", "border": "rgba(139, 92, 246, 0.3)", "text": "#7C3AED"}
]

QWEN_VOCAB_SAMPLE = {
    "<|im_start|>": 151644, "<|im_end|>": 151645, "What": 3838, "what": 1094,
    " is": 374, "is": 310, " AI": 9552, "AI": 15993, "?": 30,
    "Explain": 44439, " Machine": 6229, " Learning": 10091, " in": 304,
    " simple": 3669, " terms": 2728, "The": 791, " capital": 4310,
    " of": 315, " France": 7097, " Paris": 10186, "Python": 14197,
    " a": 264, " programming": 8459, " language": 4241, "Transformer": 73228
}


class TokenManager:
    """
    Manages Qwen2.5-1.5B tokenization and subword ID extraction.
    """
    MODEL_ID = "Qwen/Qwen2.5-1.5B-Instruct"
    VOCAB_SIZE = 151936

    def __init__(self, model_id: str = MODEL_ID):
        self.model_id = model_id
        self.hf_tokenizer = None
        self.is_live = False
        self._load()

    def _load(self):
        if HF_TOKENIZER_AVAILABLE:
            try:
                self.hf_tokenizer = AutoTokenizer.from_pretrained(self.model_id, trust_remote_code=True)
                self.is_live = True
            except Exception:
                self.hf_tokenizer = None
                self.is_live = False

    def tokenize(self, text: str) -> Dict[str, Any]:
        if not text:
            return {"tokens": [], "token_ids": [], "token_details": [], "total_tokens": 0}

        if self.is_live and self.hf_tokenizer is not None:
            ids = self.hf_tokenizer(text, return_tensors=None, add_special_tokens=False)["input_ids"]
            tokens = [self.hf_tokenizer.decode([i]) for i in ids]
        else:
            pattern = re.compile(r'( ?\w+|[^\w\s]| +|\n+)')
            tokens = pattern.findall(text) or [text]
            ids = [QWEN_VOCAB_SAMPLE.get(t, 1000 + (abs(hash(t)) % 140000)) for t in tokens]

        token_details = []
        for idx, (t, tid) in enumerate(zip(tokens, ids)):
            c = SOFT_CHIP_COLORS[idx % len(SOFT_CHIP_COLORS)]
            disp = t.replace(" ", "Ġ").replace("\n", "↵")
            token_details.append({
                "index": idx,
                "token": t,
                "display": disp if disp.strip() else "␣",
                "id": int(tid),
                "length": len(t),
                "is_space_prefixed": t.startswith(" "),
                "color": c
            })

        return {
            "tokens": tokens,
            "token_ids": ids,
            "token_details": token_details,
            "total_tokens": len(tokens),
            "vocab_size": self.VOCAB_SIZE
        }

    def decode(self, ids: List[int]) -> str:
        if self.is_live and self.hf_tokenizer:
            return self.hf_tokenizer.decode(ids)
        rev = {v: k for k, v in QWEN_VOCAB_SAMPLE.items()}
        return "".join([rev.get(i, f"<{i}>") for i in ids])
