"""
Academia AI : Streamlit Web Application (LLM & Agentic AI Edition)
Platform: www.academiaai.online
Updated Features:
- Gateway Login Page with Google Sign-In (Firebase) & Scholar Quick-Select
- Smooth transition to Main Dashboard
- Qwen 2.5 (7B Parameter) & OpenAI Models
- Persistent Cross-Chat Memory Management
- Agentic Voice Assistant & Full Document Deep Analysis
- DALL-E 3 Image Studio & LLM X-Ray Inspector
"""

import os
import time
import math
import streamlit as st
import numpy as np

from openai_engine import OpenAIEngine, MODEL_CATALOG
from tokenizer_manager import TokenizerManager
from memory_manager import ConversationMemory, SYSTEM_PERSONAS
from rag_engine import RAGEngine
from xray_engine import XRayEngine

try:
    import plotly.graph_objects as go
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False


# Page Configuration
st.set_page_config(
    page_title="Academia AI | Login & Dashboard (www.academiaai.online)",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Session State Initialization
if "is_logged_in" not in st.session_state:
    st.session_state["is_logged_in"] = False

if "theme" not in st.session_state:
    st.session_state["theme"] = "dark"

if "selected_model" not in st.session_state:
    st.session_state["selected_model"] = "gpt-4o-mini"

if "openai_api_key" not in st.session_state:
    st.session_state["openai_api_key"] = os.getenv("OPENAI_API_KEY", "")

if "persona" not in st.session_state:
    st.session_state["persona"] = "assistant"

if "messages" not in st.session_state:
    st.session_state["messages"] = []

if "active_xray" not in st.session_state:
    st.session_state["active_xray"] = None

if "user_name" not in st.session_state:
    st.session_state["user_name"] = "Sanamdeep Scholar"

if "user_email" not in st.session_state:
    st.session_state["user_email"] = "sanamdeep@academiaai.online"


# Cached Core Engines
@st.cache_resource
def get_engines():
    engine = OpenAIEngine()
    memory = ConversationMemory()
    rag = RAGEngine()
    xray = XRayEngine()
    tokenizer = TokenizerManager()
    return engine, memory, rag, xray, tokenizer

openai_engine, memory_mgr, rag_pipe, xray_inspector, tok_mgr = get_engines()

if st.session_state["openai_api_key"]:
    openai_engine.set_api_key(st.session_state["openai_api_key"])
    rag_pipe.set_openai_client(openai_engine.client)

openai_engine.set_model(st.session_state["selected_model"])
memory_mgr.set_persona(st.session_state["persona"])


# Theme Styling
is_dark = (st.session_state["theme"] == "dark")
theme_css = f"""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;700&display=swap');
    
    html, body, [class*="css"] {{
        font-family: 'Plus Jakarta Sans', sans-serif;
    }}
    
    .stApp {{
        background-color: {'#0B0F19' if is_dark else '#F8FAFC'} !important;
        background-image: {'radial-gradient(at 0% 0%, #151c2e 0px, transparent 50%), radial-gradient(at 100% 100%, #1b152e 0px, transparent 50%)' if is_dark else 'radial-gradient(at 0% 0%, #EFF6FF 0px, transparent 50%), radial-gradient(at 100% 100%, #F5F3FF 0px, transparent 50%)'} !important;
        color: {'#F8FAFC' if is_dark else '#0F172A'} !important;
    }}
    
    .login-container {{
        max-width: 500px;
        margin: 40px auto;
        background: {'rgba(17, 24, 39, 0.75)' if is_dark else '#FFFFFF'};
        backdrop-filter: blur(20px);
        border: 1px solid {'rgba(255, 255, 255, 0.12)' if is_dark else '#E2E8F0'};
        border-radius: 24px;
        padding: 36px 30px;
        text-align: center;
        box-shadow: 0 20px 48px {'rgba(0,0,0,0.45)' if is_dark else 'rgba(0,0,0,0.06)'};
    }}
    
    .login-badge {{
        width: 60px;
        height: 60px;
        border-radius: 18px;
        background: linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%);
        font-size: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 16px auto;
        box-shadow: 0 8px 24px rgba(99, 102, 241, 0.35);
    }}

    .user-bubble {{
        background: linear-gradient(135deg, #4F46E5 0%, #4338CA 100%);
        color: #FFFFFF;
        border-radius: 18px 18px 4px 18px;
        padding: 14px 20px;
        margin: 10px 0;
        max-width: 80%;
        margin-left: auto;
        box-shadow: 0 4px 14px rgba(79, 70, 229, 0.25);
    }}
    
    .ai-bubble {{
        background: {'rgba(31, 41, 55, 0.75)' if is_dark else 'rgba(255, 255, 255, 0.95)'};
        backdrop-filter: blur(12px);
        border: 1px solid {'rgba(255, 255, 255, 0.08)' if is_dark else '#E2E8F0'};
        color: {'#F3F4F6' if is_dark else '#1E293B'};
        border-radius: 18px 18px 18px 4px;
        padding: 18px 22px;
        margin: 10px 0;
        max-width: 85%;
        box-shadow: 0 4px 20px {'rgba(0,0,0,0.3)' if is_dark else 'rgba(0,0,0,0.05)'};
    }}

    .memory-tag {{
        display: inline-block;
        background: rgba(99, 102, 241, 0.15);
        color: #A78BFA;
        border: 1px solid rgba(99, 102, 241, 0.3);
        border-radius: 6px;
        padding: 4px 8px;
        font-size: 11px;
        margin: 2px;
    }}
</style>
"""
st.markdown(theme_css, unsafe_allow_html=True)


# =============================================================================
# 1. GATEWAY LOGIN PAGE VIEW
# =============================================================================
if not st.session_state["is_logged_in"]:
    col_t1, col_t2 = st.columns([4, 1])
    with col_t2:
        theme_lbl = "☀️ Light" if is_dark else "🌙 Dark"
        if st.button(theme_lbl, key="login_theme_btn"):
            st.session_state["theme"] = "light" if is_dark else "dark"
            st.rerun()

    st.markdown(
        """
        <div class="login-container">
            <div class="login-badge">🎓</div>
            <h1 style="font-weight:900; margin-bottom:4px;">Academia AI</h1>
            <p style="color:#94A3B8; font-size:14px; margin-bottom:8px;">LLM & Agentic AI Research Platform</p>
            <div style="font-size:11px; font-weight:700; color:#6366F1; margin-bottom:20px;">www.academiaai.online</div>
        </div>
        """,
        unsafe_allow_html=True
    )

    c_center = st.columns([1, 2, 1])[1]
    with c_center:
        st.markdown("#### Select Researcher Account")
        account_choice = st.radio(
            "Account",
            [
                "Sanamdeep Scholar (Lead AI Researcher)",
                "Dr. Elena Rostova (Quantum AI Faculty)",
                "Alex Chen (Senior CS Student)"
            ],
            index=0,
            label_visibility="collapsed"
        )

        st.markdown("")
        if st.button("🚀 Sign in with Google (Firebase) & Enter Dashboard", use_container_width=True):
            if "Sanamdeep" in account_choice:
                st.session_state["user_name"] = "Sanamdeep Scholar"
                st.session_state["user_email"] = "sanamdeep@academiaai.online"
            elif "Elena" in account_choice:
                st.session_state["user_name"] = "Dr. Elena Rostova"
                st.session_state["user_email"] = "elena.ai@academiaai.online"
            else:
                st.session_state["user_name"] = "Alex Chen"
                st.session_state["user_email"] = "alex.chen@academiaai.online"

            st.session_state["is_logged_in"] = True
            st.success("Authenticated! Loading Dashboard...")
            time.sleep(0.4)
            st.rerun()

        st.caption("🔒 Powered by Firebase Auth • Qwen 2.5 (7B Parameter) & OpenAI")
    st.stop()


# =============================================================================
# 2. MAIN ACADEMIA AI DASHBOARD VIEW
# =============================================================================
col_top_left, col_top_right = st.columns([3, 1])

with col_top_left:
    st.markdown(
        f"### 🎓 Academia AI : LLM & Agentic AI Platform  \n"
        f"<span style='font-size:12px; opacity:0.8;'>Model: <b>{st.session_state['selected_model']}</b> • Scholar: <b>{st.session_state['user_name']}</b> • URL: <a href='https://www.academiaai.online' target='_blank'>www.academiaai.online</a></span>",
        unsafe_allow_html=True
    )

with col_top_right:
    c_btn1, c_btn2 = st.columns([1, 1])
    with c_btn1:
        theme_btn_label = "☀️ Light" if is_dark else "🌙 Dark"
        if st.button(theme_btn_label, key="dash_theme_btn", use_container_width=True):
            st.session_state["theme"] = "light" if is_dark else "dark"
            st.rerun()
    with c_btn2:
        if st.button("🚪 Sign Out", key="dash_logout_btn", use_container_width=True):
            st.session_state["is_logged_in"] = False
            st.rerun()


# Left Sidebar: Account, Model Selector, Memory, RAG & Image Studio
with st.sidebar:
    st.markdown("### 👤 Active Scholar")
    st.caption(f"**{st.session_state['user_name']}**\n{st.session_state['user_email']}")
    if st.button("Switch Account / Sign Out", use_container_width=True):
        st.session_state["is_logged_in"] = False
        st.rerun()

    st.divider()

    st.markdown("### ⚙️ Engine & Model")
    model_choice = st.selectbox(
        "Active Model",
        options=list(MODEL_CATALOG.keys()),
        index=list(MODEL_CATALOG.keys()).index(st.session_state["selected_model"]),
        format_func=lambda m: MODEL_CATALOG[m]["name"]
    )
    if model_choice != st.session_state["selected_model"]:
        st.session_state["selected_model"] = model_choice
        openai_engine.set_model(model_choice)
        st.rerun()

    persona_choice = st.selectbox(
        "Persona Role",
        options=list(SYSTEM_PERSONAS.keys()),
        index=list(SYSTEM_PERSONAS.keys()).index(st.session_state["persona"])
    )
    if persona_choice != st.session_state["persona"]:
        st.session_state["persona"] = persona_choice
        memory_mgr.set_persona(persona_choice)

    st.divider()

    # Feature 2 & 8: Cross-Chat Memory Management
    st.markdown("### 🧠 Persistent Cross-Chat Memory")
    if memory_mgr.user_memories:
        for mem in memory_mgr.user_memories:
            c1, c2 = st.columns([5, 1])
            with c1:
                st.caption(f"• {mem['fact']}")
            with c2:
                if st.button("✕", key=f"del_{mem['id']}"):
                    memory_mgr.delete_user_memory(mem["id"])
                    st.rerun()
    else:
        st.caption("No persistent memories stored yet.")

    new_fact = st.text_input("Add Memory Fact", placeholder="e.g. 'I study Quantum AI'")
    if st.button("Add to Memory", use_container_width=True):
        if new_fact.strip():
            memory_mgr.add_user_memory(new_fact)
            st.rerun()

    st.divider()

    # Feature 5: Document Chat & Full Deep Analyzer
    st.markdown("### 📄 Document Intelligence")
    uploaded_files = st.file_uploader(
        "Upload PDF, DOCX, or TXT",
        type=["pdf", "docx", "txt", "md"],
        accept_multiple_files=True
    )
    if uploaded_files:
        for uploaded_file in uploaded_files:
            if uploaded_file.name not in [d["filename"] for d in rag_pipe.indexed_documents.values()]:
                save_path = os.path.join("data/documents", uploaded_file.name)
                with open(save_path, "wb") as f:
                    f.write(uploaded_file.getbuffer())
                with st.spinner(f"Indexing {uploaded_file.name}..."):
                    rag_pipe.ingest_document(save_path, uploaded_file.name)
                st.success(f"Indexed: {uploaded_file.name}")
                st.rerun()

    if rag_pipe.indexed_documents:
        st.markdown("**Indexed Documents:**")
        for doc in rag_pipe.indexed_documents.values():
            st.caption(f"📁 {doc['filename']} ({doc['chunk_count']} chunks)")

        if st.button("⚡ Full Document Deep Analysis", use_container_width=True):
            res = rag_pipe.analyze_full_document()
            st.session_state["messages"].append({"role": "assistant", "content": res["report"]})
            st.rerun()

    st.divider()

    # Feature 6: Image Studio (DALL-E 3)
    st.markdown("### 🎨 AI Image Studio")
    img_prompt = st.text_input("DALL-E Prompt", placeholder="e.g. 'Quantum processor in blue neon'")
    if st.button("Generate Image", use_container_width=True):
        if img_prompt.strip():
            with st.spinner("Generating with DALL-E 3..."):
                img_res = openai_engine.generate_image(img_prompt)
                st.image(img_res["image_url"], caption=img_prompt)

    st.divider()

    if st.button("➕ New Chat Session", use_container_width=True):
        st.session_state["messages"] = []
        st.session_state["active_xray"] = None
        memory_mgr.clear()
        st.rerun()


# Main Chat Area
for msg_idx, msg in enumerate(st.session_state["messages"]):
    if msg["role"] == "user":
        st.markdown(f"<div class='user-bubble'>{msg['content']}</div>", unsafe_allow_html=True)
    else:
        st.markdown(f"<div class='ai-bubble'>{msg['content']}</div>", unsafe_allow_html=True)

        if msg.get("citations"):
            st.markdown("##### 📚 Referenced Sources")
            for c in msg["citations"]:
                st.markdown(
                    f"<div class='source-card'><b>📄 {c['filename']}</b> (Page {c['page']} • Relevance {c['relevance_pct']}%)<br>"
                    f"<span style='opacity:0.8;'>{c['snippet'][:200]}...</span></div>",
                    unsafe_allow_html=True
                )

        c1, c2 = st.columns([1, 4])
        with c1:
            if st.button("🔬 Inspect X-Ray", key=f"xray_{msg_idx}"):
                st.session_state["active_xray"] = msg.get("xray")


user_prompt = st.chat_input("Ask a question, analyze documents, or speak instructions...")

if user_prompt:
    st.session_state["messages"].append({"role": "user", "content": user_prompt})
    memory_mgr.add_user_message(user_prompt)

    retrieved_chunks = []
    rag_context = ""
    if rag_pipe.chunks:
        retrieved_chunks = rag_pipe.retrieve(user_prompt, top_k=3)
        rag_context = rag_pipe.format_rag_context(retrieved_chunks)

    messages_payload = memory_mgr.build_context_messages(retrieved_context=rag_context)

    with st.spinner("Streaming response from Academia AI..."):
        stream_gen = openai_engine.stream_chat(messages_payload, enable_logprobs=True)
        response_placeholder = st.empty()
        full_response = ""
        captured_diagnostics = {}

        for chunk in stream_gen:
            if chunk.get("type") == "token":
                full_response = chunk.get("accumulated", "")
                response_placeholder.markdown(f"<div class='ai-bubble'>{full_response}▌</div>", unsafe_allow_html=True)
            elif chunk.get("type") == "done":
                captured_diagnostics = chunk.get("diagnostics", {})

        response_placeholder.markdown(f"<div class='ai-bubble'>{full_response}</div>", unsafe_allow_html=True)

    xray_pack = xray_inspector.generate_xray_package(
        prompt_text=user_prompt,
        response_text=full_response,
        diagnostics=captured_diagnostics,
        retrieved_chunks=retrieved_chunks
    )

    ai_msg_record = {
        "role": "assistant",
        "content": full_response,
        "citations": retrieved_chunks,
        "xray": xray_pack
    }
    st.session_state["messages"].append(ai_msg_record)
    st.session_state["active_xray"] = xray_pack
    st.rerun()


# LLM X-Ray Inspection Panel
if st.session_state.get("active_xray"):
    xray_data = st.session_state["active_xray"]
    st.divider()
    st.markdown("### 🔬 LLM X-Ray Inspection Panel")
    st.caption("Deep internal tensor diagnostics: BPE tokens, Logprobs Top-5, 1536-dim Embeddings, Attention, Hidden dynamics, and USD cost profiler.")

    tabs = st.tabs([
        "🔤 Tokens",
        "📊 Logprobs & Top-5",
        "🧬 Embeddings (PCA)",
        "👁️ Attention",
        "⚡ Layers",
        "📈 Cost & Latency"
    ])

    with tabs[0]:
        st.markdown("#### Subword BPE Deconstruction")
        chips_html = "".join([f"<span class='memory-tag'>{t['token']} ({t.get('probability', 90)}%)</span>" for t in xray_data.get("logprobs", [])])
        st.markdown(chips_html, unsafe_allow_html=True)

    with tabs[1]:
        st.markdown("#### Token Logprobs & Top-5 Candidate Words")
        logprobs_list = xray_data.get("logprobs", [])[:20]
        if logprobs_list and PLOTLY_AVAILABLE:
            sel_tok = logprobs_list[0]
            alts = sel_tok.get("top_alternatives", [])
            fig_logprobs = go.Figure(data=[go.Bar(
                x=[a["token"] for a in alts],
                y=[a["probability"] for a in alts],
                marker=dict(color=["#10B981" if idx==0 else "#6366F1" for idx in range(len(alts))])
            )])
            fig_logprobs.update_layout(height=280, template="plotly_dark" if is_dark else "plotly_white")
            st.plotly_chart(fig_logprobs, use_container_width=True)

    with tabs[2]:
        st.markdown("#### 1536-Dimensional Continuous Embeddings (PCA)")
        pca_pts = xray_data.get("pca_projection", [])
        if PLOTLY_AVAILABLE and pca_pts:
            fig_pca = go.Figure(data=[go.Scatter(
                x=[p["x"] for p in pca_pts],
                y=[p["y"] for p in pca_pts],
                mode="markers+text",
                text=[p["label"] for p in pca_pts],
                marker=dict(size=12, color=["#EF4444" if p["category"]=="prompt" else "#10B981" for p in pca_pts])
            )])
            fig_pca.update_layout(height=320, template="plotly_dark" if is_dark else "plotly_white")
            st.plotly_chart(fig_pca, use_container_width=True)

    with tabs[3]:
        st.markdown("#### Multi-Head Self-Attention Matrix")
        att_data = xray_data.get("attention", {})
        if PLOTLY_AVAILABLE and att_data.get("matrix"):
            fig_att = go.Figure(data=[go.Heatmap(z=att_data["matrix"], colorscale="Viridis")])
            fig_att.update_layout(height=320, template="plotly_dark" if is_dark else "plotly_white")
            st.plotly_chart(fig_att, use_container_width=True)

    with tabs[4]:
        st.markdown("#### Transformer Representation Dynamics")
        ld = xray_data.get("layer_dynamics", {})
        if PLOTLY_AVAILABLE and ld.get("layers"):
            fig_layers = go.Figure()
            fig_layers.add_trace(go.Scatter(x=ld["layers"], y=ld["hidden_norms"], name="Hidden Norm", line=dict(color="#3B82F6", width=3)))
            fig_layers.update_layout(height=300, template="plotly_dark" if is_dark else "plotly_white")
            st.plotly_chart(fig_layers, use_container_width=True)

    with tabs[5]:
        st.markdown("#### Latency & Cost Profiler")
        perf = xray_data.get("performance", {})
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("TTFT", f"{perf.get('ttft_ms')} ms")
        c2.metric("Throughput", f"{perf.get('tokens_per_second')} tok/s")
        c3.metric("Prompt Tokens", f"{perf.get('prompt_tokens')}")
        c4.metric("Est. Cost", f"${perf.get('estimated_cost_usd'):.6f}")
