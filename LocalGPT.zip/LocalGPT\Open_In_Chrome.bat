@echo off
title Launch LocalGPT in Chrome
start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" "file:///%~dp0LocalGPT.html"
if %ERRORLEVEL% neq 0 (
    start "" "chrome.exe" "file:///%~dp0LocalGPT.html"
)
exit
