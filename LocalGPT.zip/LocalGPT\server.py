"""
OpenGPT-XRay: Full-Stack Application Server (Academia AI Edition)
Provides REST endpoints and Server-Sent Events (SSE) streaming for:
- Chat & Title Auto-Summarization
- Agentic Tool Operations & Voice Commands
- Persistent Cross-Chat Memory Management
- Full Document Deep Analysis
- DALL-E Image Generation Studio
- Google Authentication & Account Profile
"""

import os
import sys
import json
import time
import urllib.parse
from typing import Dict, Any, List

from openai_engine import OpenAIEngine, MODEL_CATALOG
from memory_manager import ConversationMemory
from rag_engine import RAGEngine
from xray_engine import XRayEngine
from tokenizer_manager import TokenizerManager

# Initialize core singletons
openai_engine = OpenAIEngine()
memory_manager = ConversationMemory()
rag_engine = RAGEngine(openai_client=openai_engine.client)
xray_engine = XRayEngine()
tokenizer_manager = TokenizerManager()

message_diagnostics_store: Dict[str, Dict[str, Any]] = {}

# Active User Profile (Google Auth via Firebase or One-Click Demo)
current_user_profile = {
    "signed_in": True,
    "name": "Academia Scholar",
    "email": "scholar@academiaai.online",
    "avatar": "https://api.dicebear.com/7.x/bottts/svg?seed=Academia",
    "role": "AI Researcher & Student",
    "firebase_configured": False
}


def process_chat_query(
    user_message: str,
    model: str = "gpt-4o-mini",
    persona: str = "assistant",
    use_rag: bool = True,
    temperature: float = 0.7
):
    openai_engine.set_model(model)
    memory_manager.set_persona(persona)

    # 1. Add User Message
    user_msg_obj = memory_manager.add_user_message(user_message)

    # 2. Check for 1st prompt to summarize chat title
    if len(memory_manager.history) == 1:
        auto_title = openai_engine.generate_chat_title(user_message)
        memory_manager.set_session_title(auto_title)

    # 3. RAG Retrieval if active
    retrieved_chunks = []
    rag_context = ""
    if use_rag and rag_engine.chunks:
        retrieved_chunks = rag_engine.retrieve(user_message, top_k=3)
        rag_context = rag_engine.format_rag_context(retrieved_chunks)

    # 4. Context Messages with Memory & Persona
    messages = memory_manager.build_context_messages(retrieved_context=rag_context)

    # 5. Stream response
    stream_generator = openai_engine.stream_chat(
        messages=messages,
        temperature=temperature,
        enable_logprobs=True
    )

    accumulated_text = ""
    diagnostics = {}

    for packet in stream_generator:
        p_type = packet.get("type")
        if p_type == "token":
            accumulated_text = packet.get("accumulated", "")
            yield {
                "event": "token",
                "delta": packet.get("delta", ""),
                "accumulated": accumulated_text,
                "token_info": packet.get("token_info")
            }
        elif p_type == "done":
            diagnostics = packet.get("diagnostics", {})

    # 6. Build X-Ray Package
    xray_package = xray_engine.generate_xray_package(
        prompt_text=user_message,
        response_text=accumulated_text,
        diagnostics=diagnostics,
        retrieved_chunks=retrieved_chunks
    )

    # 7. Store Assistant Message
    ai_msg_obj = memory_manager.add_assistant_message(
        content=accumulated_text,
        diagnostics=diagnostics,
        citations=retrieved_chunks
    )
    message_diagnostics_store[ai_msg_obj["id"]] = xray_package

    yield {
        "event": "completed",
        "message_id": ai_msg_obj["id"],
        "content": accumulated_text,
        "diagnostics": diagnostics,
        "citations": retrieved_chunks,
        "xray": xray_package,
        "session_title": memory_manager.active_session_title
    }


# -----------------------------------------------------------------------------
# Standard Library HTTP Server Handler
# -----------------------------------------------------------------------------
from http.server import HTTPServer, SimpleHTTPRequestHandler


class AcademiaHTTPHandler(SimpleHTTPRequestHandler):

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, DELETE")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path == "/api/status":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            status = {
                "status": "online",
                "brand": "Academia AI (www.academiaai.online)",
                "is_connected": openai_engine.is_connected(),
                "model": openai_engine.model,
                "persona": memory_manager.persona_key,
                "indexed_documents_count": len(rag_engine.indexed_documents),
                "total_chunks": len(rag_engine.chunks),
                "user": current_user_profile,
                "user_memories_count": len(memory_manager.user_memories)
            }
            self.wfile.write(json.dumps(status).encode("utf-8"))
            return

        elif path == "/api/models":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(MODEL_CATALOG).encode("utf-8"))
            return

        elif path == "/api/memory":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(memory_manager.user_memories).encode("utf-8"))
            return

        elif path == "/api/documents":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            docs = list(rag_engine.indexed_documents.values())
            self.wfile.write(json.dumps(docs).encode("utf-8"))
            return

        elif path == "/api/conversations":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            sessions = memory_manager.list_sessions()
            self.wfile.write(json.dumps(sessions).encode("utf-8"))
            return

        elif path.startswith("/api/xray/"):
            msg_id = path.replace("/api/xray/", "")
            xray_data = message_diagnostics_store.get(msg_id, {})
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(xray_data).encode("utf-8"))
            return

        return super().do_GET()

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)

        if path == "/api/chat":
            try:
                data = json.loads(body.decode("utf-8"))
                user_msg = data.get("message", "")
                model = data.get("model", "gpt-4o-mini")
                persona = data.get("persona", "assistant")
                use_rag = data.get("use_rag", True)
                temp = float(data.get("temperature", 0.7))

                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "keep-alive")
                self.end_headers()

                for packet in process_chat_query(user_msg, model, persona, use_rag, temp):
                    payload = f"data: {json.dumps(packet)}\n\n"
                    self.wfile.write(payload.encode("utf-8"))
                    self.wfile.flush()

            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode("utf-8"))
            return

        elif path == "/api/generate-image":
            try:
                data = json.loads(body.decode("utf-8"))
                prompt = data.get("prompt", "Academic visualization of artificial intelligence")
                style = data.get("style", "vivid")
                result = openai_engine.generate_image(prompt, style=style)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode("utf-8"))
            except Exception as e:
                self.send_response(500)
                self.end_headers()
            return

        elif path == "/api/analyze-full-doc":
            try:
                data = json.loads(body.decode("utf-8"))
                doc_id = data.get("doc_id")
                user_prompt = data.get("prompt")
                result = rag_engine.analyze_full_document(doc_id=doc_id, user_prompt=user_prompt)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode("utf-8"))
            except Exception as e:
                self.send_response(500)
                self.end_headers()
            return

        elif path == "/api/memory/add":
            try:
                data = json.loads(body.decode("utf-8"))
                fact = data.get("fact", "")
                mem = memory_manager.add_user_memory(fact)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"success": True, "memory": mem}).encode("utf-8"))
            except Exception as e:
                self.send_response(400)
                self.end_headers()
            return

        elif path == "/api/memory/delete":
            try:
                data = json.loads(body.decode("utf-8"))
                mem_id = data.get("id")
                success = memory_manager.delete_user_memory(mem_id)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"success": success}).encode("utf-8"))
            except Exception as e:
                self.send_response(400)
                self.end_headers()
            return

        elif path == "/api/memory/clear":
            memory_manager.clear_all_memories()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"success": True}).encode("utf-8"))
            return

        elif path == "/api/config":
            try:
                data = json.loads(body.decode("utf-8"))
                api_key = data.get("api_key")
                model = data.get("model")
                persona = data.get("persona")

                if api_key is not None:
                    openai_engine.set_api_key(api_key)
                    rag_engine.set_openai_client(openai_engine.client)
                if model:
                    openai_engine.set_model(model)
                if persona:
                    memory_manager.set_persona(persona)

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"success": True, "connected": openai_engine.is_connected()}).encode("utf-8"))
            except Exception:
                self.send_response(400)
                self.end_headers()
            return

        elif path == "/api/conversations/clear":
            memory_manager.clear()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"success": True}).encode("utf-8"))
            return

        self.send_response(404)
        self.end_headers()


def start_server(port: int = 8080):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    server_address = ("127.0.0.1", port)
    httpd = HTTPServer(server_address, AcademiaHTTPHandler)
    print(f"================================================================")
    print(f"  Academia AI : LLM & Agentic AI Server running on:")
    print(f"  http://127.0.0.1:{port}")
    print(f"================================================================")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down server...")
        httpd.server_close()


if __name__ == "__main__":
    start_server()
