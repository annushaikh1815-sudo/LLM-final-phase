@echo off
title LocalGPT : Launch AI Assistant
echo ========================================================
echo        LocalGPT: ChatGPT-Style Local AI Assistant
echo ========================================================
echo.
echo Launching LocalGPT interactive interface in your browser...
echo.
if exist "%~dp0LocalGPT.html" (
    start "" "%~dp0LocalGPT.html"
) else (
    start "" "%~dp0index.html"
)
echo [SUCCESS] LocalGPT launched in your browser!
timeout /t 3 >nul
exit /b
