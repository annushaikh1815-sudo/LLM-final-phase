"""
OpenGPT-XRay: Memory & Context Manager Module (Academia AI Edition)
Manages multi-turn conversation memory, sliding token window budgeting,
long-term cross-chat persistent user memory, and system persona presets.
"""

import json
import os
import re
import time
from typing import List, Dict, Any, Optional
from tokenizer_manager import TokenizerManager


SYSTEM_PERSONAS = {
    "assistant": (
        "You are Academia AI (powered by Qwen 2.5 & OpenAI), a highly capable, articulate, and precise academic assistant. "
        "You provide well-structured explanations, clear markdown tables, accurate code blocks with language tags, "
        "and factually grounded citations."
    ),
    "code_architect": (
        "You are an Elite Software Architect and Senior Engineer at Academia AI. "
        "You write robust, production-grade code, analyze algorithmic complexities, adhere to best practices, "
        "and provide crystal clear step-by-step technical explanations."
    ),
    "research_scientist": (
        "You are an AI Research Scientist at Academia AI (www.academiaai.online). "
        "You emphasize empirical precision, mathematical foundations, data-driven synthesis, "
        "and provide rigorous citations for all claims."
    ),
    "concise_analyst": (
        "You are an Executive Technology Analyst at Academia AI. "
        "You deliver direct, high-impact bullet points, concise executive summaries, "
        "and actionable insights with zero fluff."
    )
}


class ConversationMemory:
    """
    Maintains multi-turn conversation history, persistent cross-chat memory,
    and token budget limits.
    """

    MAX_CONTEXT_TOKENS = 120000
    TARGET_HISTORY_TOKENS = 8000

    def __init__(
        self,
        storage_dir: str = "data/conversations",
        memory_file: str = "data/user_memory.json",
        persona_key: str = "assistant"
    ):
        self.storage_dir = storage_dir
        self.memory_file = memory_file
        self.persona_key = persona_key
        self.system_prompt = SYSTEM_PERSONAS.get(persona_key, SYSTEM_PERSONAS["assistant"])
        self.tokenizer = TokenizerManager()
        self.active_session_id = f"chat_{int(time.time())}"
        self.active_session_title = "New Chat"
        self.history: List[Dict[str, Any]] = []
        self.user_memories: List[Dict[str, Any]] = []

        os.makedirs(self.storage_dir, exist_ok=True)
        os.makedirs(os.path.dirname(self.memory_file) or ".", exist_ok=True)
        self.load_user_memories()

    # -------------------------------------------------------------------------
    # Persistent Cross-Chat User Memory (Feature 2 & 8)
    # -------------------------------------------------------------------------
    def load_user_memories(self):
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, "r", encoding="utf-8") as f:
                    self.user_memories = json.load(f)
            except Exception:
                self.user_memories = []
        else:
            # Seed default educational memories
            self.user_memories = [
                {"id": "mem_1", "fact": "User is affiliated with Academia AI (academiaai.online)", "created_at": time.time()},
                {"id": "mem_2", "fact": "User is studying Agentic AI, LLM architectures, and RAG systems", "created_at": time.time()}
            ]
            self.save_user_memories()

    def save_user_memories(self):
        try:
            with open(self.memory_file, "w", encoding="utf-8") as f:
                json.dump(self.user_memories, f, indent=2)
        except Exception as e:
            print(f"[ConversationMemory] Error saving user memories: {e}")

    def add_user_memory(self, fact: str) -> Dict[str, Any]:
        """
        Stores a persistent cross-chat fact about the user.
        """
        mem_obj = {
            "id": f"mem_{int(time.time() * 1000)}",
            "fact": fact.strip(),
            "created_at": time.time()
        }
        self.user_memories.append(mem_obj)
        self.save_user_memories()
        return mem_obj

    def delete_user_memory(self, memory_id: str) -> bool:
        """
        Removes a specific memory by ID.
        """
        before_count = len(self.user_memories)
        self.user_memories = [m for m in self.user_memories if m["id"] != memory_id]
        if len(self.user_memories) < before_count:
            self.save_user_memories()
            return True
        return False

    def clear_all_memories(self):
        self.user_memories = []
        self.save_user_memories()

    def extract_and_store_facts(self, user_prompt: str):
        """
        Heuristic extractor for user preference statements:
        e.g., "I prefer Python", "I am studying computer science", "My name is Alex".
        """
        patterns = [
            r"\b(i am|i'm|my name is)\s+([a-zA-Z0-9\s]{3,35})\b",
            r"\b(i prefer|i like|i love)\s+([a-zA-Z0-9\s]{3,35})\b",
            r"\b(my major is|i study|i work at)\s+([a-zA-Z0-9\s]{3,35})\b"
        ]
        for p in patterns:
            match = re.search(p, user_prompt, re.IGNORECASE)
            if match:
                extracted = match.group(0).strip().capitalize()
                # Check for duplicates
                if not any(extracted.lower() in m["fact"].lower() for m in self.user_memories):
                    self.add_user_memory(extracted)
                break

    # -------------------------------------------------------------------------
    # Conversation Session Management
    # -------------------------------------------------------------------------
    def set_persona(self, persona_key: str, custom_text: Optional[str] = None):
        if custom_text:
            self.persona_key = "custom"
            self.system_prompt = custom_text
        elif persona_key in SYSTEM_PERSONAS:
            self.persona_key = persona_key
            self.system_prompt = SYSTEM_PERSONAS[persona_key]

    def add_user_message(self, content: str) -> Dict[str, Any]:
        msg = {
            "id": f"msg_user_{int(time.time() * 1000)}",
            "role": "user",
            "content": content,
            "timestamp": time.time()
        }
        self.history.append(msg)
        # Attempt auto-fact retention
        self.extract_and_store_facts(content)
        self.save_session()
        return msg

    def add_assistant_message(
        self,
        content: str,
        diagnostics: Optional[Dict[str, Any]] = None,
        citations: Optional[List[Dict[str, Any]]] = None
    ) -> Dict[str, Any]:
        msg = {
            "id": f"msg_ai_{int(time.time() * 1000)}",
            "role": "assistant",
            "content": content,
            "timestamp": time.time(),
            "diagnostics": diagnostics or {},
            "citations": citations or []
        }
        self.history.append(msg)
        self.save_session()
        return msg

    def build_context_messages(
        self,
        retrieved_context: Optional[str] = None,
        max_prompt_tokens: int = TARGET_HISTORY_TOKENS
    ) -> List[Dict[str, str]]:
        """
        Combines System Persona, Cross-Chat User Memory, RAG Context, and Rolling History.
        """
        system_content = self.system_prompt

        # Inject Cross-Chat Persistent User Memories (Feature 2)
        if self.user_memories:
            memory_bullet_points = "\n".join([f"- {m['fact']}" for m in self.user_memories])
            system_content += (
                "\n\n=== REMEMBERED USER PROFILE & MEMORIES (Cross-Chat Persistence) ===\n"
                f"{memory_bullet_points}\n"
                "(Use these remembered facts to personalize your assistance seamlessly.)\n"
            )

        if retrieved_context:
            system_content += (
                "\n\n=== RETRIEVED REFERENCE CONTEXT ===\n"
                f"{retrieved_context}\n"
                "=== INSTRUCTION ===\n"
                "Answer the user's question accurately using the reference context above whenever relevant. "
                "Cite your sources with [Source: <filename>, Page: <page>] when referencing retrieved facts."
            )

        messages = [{"role": "system", "content": system_content}]

        system_tokens = self.tokenizer.count_tokens(system_content)
        available_history_tokens = max(500, max_prompt_tokens - system_tokens)

        selected_history = []
        accumulated_tokens = 0

        for msg in reversed(self.history):
            msg_content = msg.get("content", "")
            msg_tokens = self.tokenizer.count_tokens(msg_content) + 4
            if accumulated_tokens + msg_tokens > available_history_tokens:
                break
            selected_history.insert(0, {"role": msg["role"], "content": msg_content})
            accumulated_tokens += msg_tokens

        messages.extend(selected_history)
        return messages

    def clear(self):
        self.history = []
        self.active_session_id = f"chat_{int(time.time())}"
        self.active_session_title = "New Chat"
        self.save_session()

    def set_session_title(self, title: str):
        self.active_session_title = title
        self.save_session()

    def save_session(self):
        filepath = os.path.join(self.storage_dir, f"{self.active_session_id}.json")
        try:
            data = {
                "session_id": self.active_session_id,
                "title": self.active_session_title,
                "persona": self.persona_key,
                "system_prompt": self.system_prompt,
                "updated_at": time.time(),
                "messages": self.history
            }
            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"[ConversationMemory] Error saving session: {e}")

    def load_session(self, session_id: str) -> bool:
        filepath = os.path.join(self.storage_dir, f"{session_id}.json")
        if not os.path.exists(filepath):
            return False
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.active_session_id = session_id
            self.active_session_title = data.get("title", "Saved Chat")
            self.persona_key = data.get("persona", "assistant")
            self.system_prompt = data.get("system_prompt", SYSTEM_PERSONAS["assistant"])
            self.history = data.get("messages", [])
            return True
        except Exception as e:
            print(f"[ConversationMemory] Error loading session: {e}")
            return False

    def list_sessions(self) -> List[Dict[str, Any]]:
        sessions = []
        if not os.path.exists(self.storage_dir):
            return sessions

        for filename in os.listdir(self.storage_dir):
            if filename.endswith(".json"):
                path = os.path.join(self.storage_dir, filename)
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    session_id = data.get("session_id", filename.replace(".json", ""))
                    messages = data.get("messages", [])
                    title = data.get("title") or (messages[0]["content"][:32] if messages else "Empty Chat")
                    sessions.append({
                        "id": session_id,
                        "title": title,
                        "updated_at": data.get("updated_at", 0),
                        "message_count": len(messages)
                    })
                except Exception:
                    continue

        sessions.sort(key=lambda s: s["updated_at"], reverse=True)
        return sessions
