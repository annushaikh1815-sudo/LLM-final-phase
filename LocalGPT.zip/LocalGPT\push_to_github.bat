@echo off
title LocalGPT : Push to GitHub
echo ========================================================
echo        LocalGPT - 1-Click Push to GitHub Helper
echo ========================================================
echo.
cd /d "%~dp0"

echo [1/4] Checking Git installation...
where git >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Git is not installed or not in your system PATH.
    echo Please install Git from https://git-scm.com/download/win
    echo After installing Git, re-run this script.
    echo.
    pause
    exit /b
)

echo [2/4] Initializing Git repository...
if not exist ".git" (
    git init
    git branch -M main
)

echo [3/4] Staging and committing files...
git add .
git commit -m "feat: complete LocalGPT AI assistant with RAG, LLM X-Ray, voice, PDF export, and code/image generation"

echo.
echo [4/4] Setting remote GitHub repository...
set /p REPO_URL="Enter your GitHub Repository URL (e.g. https://github.com/your-username/LocalGPT.git): "

if "%REPO_URL%"=="" (
    echo [INFO] No URL entered. Files are committed locally.
    echo When ready, run:
    echo   git remote add origin YOUR_GITHUB_URL
    echo   git push -u origin main
) else (
    git remote remove origin >nul 2>&1
    git remote add origin %REPO_URL%
    echo Pushing to GitHub main branch...
    git push -u origin main
    if %ERRORLEVEL% equ 0 (
        echo.
        echo [SUCCESS] Your project has been pushed to GitHub!
    ) else (
        echo.
        echo [NOTE] If push failed due to authentication, please log in with GitHub CLI or Personal Access Token:
        echo   git push -u origin main
    )
)

echo.
pause
