@echo off
title LocalGPT: Server Launcher
echo ========================================================
echo        LocalGPT: AI Assistant Server Launcher
echo ========================================================
echo.
cd /d "%~dp0"

where python >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [INFO] Starting LocalGPT Backend Server with python...
    python server.py
    pause
    exit /b
)

where py >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [INFO] Starting LocalGPT Backend Server with py launcher...
    py server.py
    pause
    exit /b
)

where streamlit >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo [INFO] Starting Streamlit App...
    streamlit run app.py
    pause
    exit /b
)

echo [INFO] Python runtime was not detected in PATH.
echo [INFO] Launching instant standalone browser app instead...
start "" "%~dp0index.html"
pause
